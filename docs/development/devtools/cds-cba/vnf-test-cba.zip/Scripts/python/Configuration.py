#!/usr/bin/python

import sys
import logging

logging.getLogger().setLevel(logging.INFO)

if __name__ == "__main__":
    logging.info("Arguments : " + str(sys.argv[1]))
    vfStatus = sys.argv[1].split(',')[0]
    if vfStatus != "Active":
        sys.exit(1)
    sys.exit(0)
