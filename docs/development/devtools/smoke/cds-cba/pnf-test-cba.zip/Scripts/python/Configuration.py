#!/usr/bin/python

import sys
import logging
import time
import requests
import constant
from datetime import datetime
import json
import xml.etree.ElementTree as ET

logging.getLogger().setLevel(logging.INFO)


class PnfUpdate:

    def process(self):
        """Handles the whole process of configuring the device. """

        logging.info("Device Details in A&AI before")
        response_aai = self.get_aai().json()

        if response_aai["pnf-name2"] != constant.HOSTNAME:
            if self.is_pnf_valid():
                response = self.update_aai(response_aai)
                if self.response_validation(response):
                    logging.info("A&AI updated successfully. New AAI Details")
                    self.get_aai().json()
                else:
                    logging.info(response)
                    logging.error("Problem while updating A&AI")
            else:
                raise Exception("Not allowed to change PNF config!!")

    def response_validation(self, response):
        """
        Check if the response is valid
        :param response- response received
        :return boolean true if the response is valid else false:
        """
        response_valid = response != "" and (response.status_code == 201 or response.status_code == 200)
        return response_valid

    def is_pnf_valid(self):
        """
        Check if the action is made against the Pnf name that is allowed to be configured
        :return boolean true if the pnfName is valid else false:
        """
        local_pnf_name = constant.DEVICE_NAME
        response_valid = False
        if local_pnf_name == "simple-cl-pnf-failure":
            logging.error("Changes not allowed on simple-cl-pnf-failure")
            raise Exception("Changes not allowed on simple-cl-pnf-failure")
        else:
            logging.info("Hostname modified successfully")
            response_valid = True
        return response_valid

    def get_aai(self):
        """
        Get PNF object from AAI
        :return:
        """
        request_url = constant.A_AI_URL + "/" + constant.DEVICE_NAME
        headers_data = constant.A_AI_HEADERS
        try:
            response = requests.get(url=request_url, headers=headers_data)
            logging.info(response.text)
            # If response was successful no Exception will be raised
            response.raise_for_status()
        except requests.RequestException as e:
            logging.error(str(e))
            raise
        return response

    def update_aai(self, aai_data):
        """
        Used to update the inventory in A&AI with the new hostname that is being received from policy
        :return:
        """
        request_url = constant.A_AI_URL + "/" + aai_data["pnf-name"]
        headers_data = constant.A_AI_HEADERS
        headers_data['x-transactionId'] = str(int(headers_data['x-transactionId'])+1)
        payload_data = aai_data
        logging.info("Device name updating A&AI : " + constant.HOSTNAME)
        payload_data["pnf-name2"] = constant.HOSTNAME
        try:
            response = requests.put(url=request_url, headers=headers_data, data=json.dumps(payload_data))
            # If response was successful no Exception will be raised
            response.raise_for_status()
        except requests.RequestException as e:
            logging.error(str(e))
            raise
        return response


if __name__ == "__main__":
    logging.info("Arguments : " + str(sys.argv[1]))
    # Assigning output variables from resource resolution to constants
    hostname = sys.argv[1].split(',')[0]
    IP = sys.argv[1].split(',')[1]
    pnfName = sys.argv[1].split(',')[2]
    constant.HOSTNAME = hostname
    constant.DEVICE_NAME = pnfName
    pnfUpdate = PnfUpdate()
    pnfUpdate.is_pnf_valid()
    sys.exit(0)
