DEVICE_NAME = "927b2580-36d9-4f13-8421-3c9d43b7a57e"

HOSTNAME = "testing-hostname"

A_AI_URL = "https://aai:8443/aai/v14/network/pnfs/pnf"

SERVER_NAME = "opendaylight.fireants-simple-cl"

PORT_NUMBER = "8283"

MODULE_NAME = "hostname"

CONTAINER_NAME = "system"

CONFIGURATION_BODY = "<system xmlns='urn:opendaylight:hostname'>\
    <hostname>hostname11</hostname>\
    <timestamp>1617119173298</timestamp>\
</system>"

HEADERS = {
    "Content-Type": "application/xml",
    "Accept": "application/xml",
    "Authorization": "Basic YWRtaW46YWRtaW4="
}

A_AI_HEADERS = {
    "Content-Type": "application/json",
    "Authorization": "Basic QUFJOkFBSQ==",
    "X-FromAppId": "CDS",
    "x-transactionId": "9998",
    "Accept": "application/json"
}
